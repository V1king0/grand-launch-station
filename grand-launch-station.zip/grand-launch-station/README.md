# grand-launch-station — Dockerized

## Prereqs
- Repo cloned on host
- Docker & Compose installed

## Build & Run
```bash
docker compose up -d --build
