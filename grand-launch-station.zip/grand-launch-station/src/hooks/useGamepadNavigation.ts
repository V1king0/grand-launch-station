import { useEffect, useRef } from "react";

type NavHandlers = {
  onLeft: () => void;
  onRight: () => void;
  onUp: () => void;
  onDown: () => void;
  onActivate: () => void;  // A / Start / Enter
  onBack?: () => void;     // B / Escape (optional)
};

export function useGamepadNavigation(handlers: NavHandlers) {
  const raf = useRef<number | null>(null);
  const lastBtn = useRef<Record<number, boolean>>({});
  const lastAxes = useRef({ x: 0, y: 0 });
  const repeatCooldown = useRef(0);

  const deadzone = 0.35; // ignore tiny stick noise
  const repeatMs = 160;  // hold-to-repeat rate

  useEffect(() => {
    const loop = () => {
      const gamepads = navigator.getGamepads ? Array.from(navigator.getGamepads()).filter(Boolean) : [];
      const gp = gamepads[0] as Gamepad | undefined;

      if (gp) {
        // Standard mapping (Chromium / Xbox controller)
        const A = 0, B = 1, START = 9;
        const DPAD_UP = 12, DPAD_DOWN = 13, DPAD_LEFT = 14, DPAD_RIGHT = 15;

        const pressed = (idx: number) => !!gp.buttons[idx]?.pressed;

        // Edge trigger helper for buttons
        const edge = (idx: number, cb: () => void) => {
          const prev = !!lastBtn.current[idx];
          const now = pressed(idx);
          if (!prev && now) cb();
          lastBtn.current[idx] = now;
        };

        edge(A, handlers.onActivate);
        edge(START, handlers.onActivate);
        if (handlers.onBack) edge(B, handlers.onBack);

        const now = performance.now();
        const canRepeat = now > repeatCooldown.current;

        // D-pad digital nav
        const dpad = {
          left: pressed(DPAD_LEFT),
          right: pressed(DPAD_RIGHT),
          up: pressed(DPAD_UP),
          down: pressed(DPAD_DOWN),
        };
        if (canRepeat && (dpad.left || dpad.right || dpad.up || dpad.down)) {
          if (dpad.left) handlers.onLeft();
          if (dpad.right) handlers.onRight();
          if (dpad.up) handlers.onUp();
          if (dpad.down) handlers.onDown();
          repeatCooldown.current = now + repeatMs;
        }

        // Left stick analog nav
        const axX = gp.axes[0] ?? 0;
        const axY = gp.axes[1] ?? 0;
        const normX = Math.abs(axX) > deadzone ? Math.sign(axX) : 0;
        const normY = Math.abs(axY) > deadzone ? Math.sign(axY) : 0;

        const movedX = normX !== lastAxes.current.x;
        const movedY = normY !== lastAxes.current.y;

        if (canRepeat && (movedX || movedY)) {
          if (normX < 0) handlers.onLeft();
          if (normX > 0) handlers.onRight();
          if (normY < 0) handlers.onUp();
          if (normY > 0) handlers.onDown();
          repeatCooldown.current = now + repeatMs;
        }

        lastAxes.current = { x: normX, y: normY };
      }

      raf.current = requestAnimationFrame(loop);
    };

    raf.current = requestAnimationFrame(loop);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); };
  }, [handlers]);
}
