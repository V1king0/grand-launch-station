import React, { useEffect, useMemo, useRef, useState } from "react";
import { Gamepad2, Youtube, Globe, Play, MonitorPlay, Joystick } from "lucide-react";
import { LauncherTile } from "./LauncherTile";
import { SmokeParticles } from "./SmokeParticles";
import { useToast } from "@/hooks/use-toast";
import { useGamepadNavigation } from "@/hooks/useGamepadNavigation";

// Helper: choose grid columns by breakpoint (1 / 2 / 3)
function useColumnsByWidth() {
  const [cols, setCols] = useState(3);
  useEffect(() => {
    const calc = () => {
      const w = window.innerWidth;
      setCols(w < 640 ? 1 : w < 1024 ? 2 : 3); // <sm:1, <lg:2, else 3
    };
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);
  return cols;
}

export const GameLauncher = () => {
  const { toast } = useToast();
  const [focused, setFocused] = useState(0);
  const cols = useColumnsByWidth();
  const refs = useRef<HTMLDivElement[]>([]);

  // Your tiles, unchanged except Steam Link scheme + RetroPie scheme
  const apps = useMemo(() => ([
    {
      title: "SteamLink",
      description: "Stream your PC games in style",
      icon: MonitorPlay,
      glowColor: "accent" as const,
      // Use the custom scheme you registered via shim:
      action: () => window.open("steamlink-local://launch", "_self"),
      // If you didn't make the shim, try "steamlink://run" (may show invite err on some builds)
    },
    {
      title: "Xbox Cloud",
      description: "Cloud gaming & Game Pass",
      icon: Gamepad2,
      glowColor: "secondary" as const,
      action: () => window.open("https://www.xbox.com/play", "_blank"),
    },
    {
      title: "Retro Arcade",
      description: "Classic games & nostalgia",
      icon: Joystick,
      glowColor: "primary" as const,
      // Launch RetroPie (EmulationStation) via custom URL scheme
      action: () => window.open("retropie-local://launch", "_self"),
    },
    {
      title: "YouTube",
      description: "Chill beats & entertainment",
      icon: Youtube,
      glowColor: "accent" as const,
      action: () => window.open("https://youtube.com", "_blank"),
    },
    {
      title: "Browser",
      description: "Explore the web freely",
      icon: Globe,
      glowColor: "secondary" as const,
      action: () => window.open("about:blank", "_blank"),
    },
    {
      title: "Media Hub",
      description: "Local content & streaming",
      icon: Play,
      glowColor: "primary" as const,
      action: () => window.open("vlc://", "_self"),
    },
  ]), []);

  // Focus the selected tile in DOM so the ring shows and keyboard works
  useEffect(() => {
    const el = refs.current[focused];
    el?.focus({ preventScroll: false });
    el?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [focused]);

  // Launch helper (keeps your toast)
  const activate = () => {
    const app = apps[focused];
    toast({ title: `Launching ${app.title}`, description: app.description });
    setTimeout(() => app.action(), 120);
  };

  // Keyboard fallback (arrows + Enter)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter") return activate();
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(e.key)) {
        e.preventDefault();
        const row = Math.floor(focused / cols);
        const col = focused % cols;
        let next = focused;
        if (e.key === "ArrowLeft")  next = Math.max(0, focused - 1);
        if (e.key === "ArrowRight") next = Math.min(apps.length - 1, focused + 1);
        if (e.key === "ArrowUp")    next = Math.max(0, (row - 1) * cols + col);
        if (e.key === "ArrowDown")  next = Math.min(apps.length - 1, (row + 1) * cols + col);
        setFocused(next);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [focused, cols, apps.length]);

  // Gamepad wiring 🎮
  useGamepadNavigation({
    onLeft:  () => setFocused((i) => Math.max(0, i - 1)),
    onRight: () => setFocused((i) => Math.min(apps.length - 1, i + 1)),
    onUp:    () => setFocused((i) => Math.max(0, i - cols)),
    onDown:  () => setFocused((i) => Math.min(apps.length - 1, i + cols)),
    onActivate: activate,
    onBack: () => {/* optional: toast({ title: "Back" }) */},
  });

  const handleAppLaunch = (app: typeof apps[number]) => {
    toast({ title: `Launching ${app.title}`, description: app.description });
    setTimeout(() => app.action(), 120);
  };

  return (
    <div className="min-h-screen smoke-bg relative overflow-hidden">
      <SmokeParticles />

      <div className="container mx-auto px-6 py-12 relative z-10">
        {/* 18+ badge, hero, etc… keep your existing markup if you like */}
        <div className="text-center mb-16">
          <div className="animate-puff-breathe mb-8">
            <h1 className="text-6xl md:text-8xl font-bold gradient-hero animate-gradient">
              PUFF-HUB
            </h1>
          </div>
          <p className="text-xl md:text-2xl text-muted-foreground mb-4">
            Your premium gaming & entertainment console
          </p>
          <p className="text-sm text-muted-foreground/70 mb-8">
            For adult use only • Must be 18+ to operate
          </p>
          <div className="w-32 h-1 bg-gradient-primary mx-auto rounded-full animate-pulse-glow" />
        </div>

        {/* Grid of tiles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {apps.map((app, index) => (
            <LauncherTile
              key={app.title}
              title={app.title}
              description={app.description}
              icon={app.icon}
              glowColor={app.glowColor}
              onClick={() => handleAppLaunch(app)}
              focused={index === focused}
              tabIndex={0}
              ref={(el) => { if (el) refs.current[index] = el; }}
            />
          ))}
        </div>

        <div className="text-center mt-8 text-sm opacity-70">
          Use D-pad/Left-stick to move • A/Start to launch • Arrows/Enter also work
        </div>
      </div>
    </div>
  );
};
