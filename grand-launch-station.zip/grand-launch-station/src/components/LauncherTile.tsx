import React, { forwardRef } from "react";
import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

// If you don't have a cn util, replace cn(...) with a simple string join.
const cn = (...cls: Array<string | false | undefined>) => cls.filter(Boolean).join(" ");

interface LauncherTileProps {
  title: string;
  description: string;
  icon: LucideIcon;
  onClick: () => void;
  glowColor?: "primary" | "secondary" | "accent";
  focused?: boolean;   // NEW
  tabIndex?: number;   // NEW
}

export const LauncherTile = forwardRef<HTMLDivElement, LauncherTileProps>(function LauncherTile(
  { title, description, icon: Icon, onClick, glowColor = "primary", focused = false, tabIndex = 0 },
  ref
) {
  const glowClass = {
    primary: "hover:shadow-glow-primary",
    secondary: "hover:shadow-glow-secondary",
    accent: "hover:shadow-glow-accent",
  }[glowColor];

  return (
    <Card
      ref={ref}
      tabIndex={tabIndex}
      onClick={onClick}
      className={cn(
        "launcher-tile cursor-pointer p-8 transition-glow outline-none group relative overflow-hidden",
        glowClass,
        focused && "ring-2 ring-offset-2 ring-accent"
      )}
    >
      {/* Subtle smoke overlay on hover */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 bg-gradient-smoke" />

      <div className="flex flex-col items-center text-center space-y-4 relative z-10">
        <div className="relative">
          <Icon
            size={64}
            className="text-primary group-hover:text-accent transition-colors duration-300 group-hover:animate-puff-breathe"
          />
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Icon size={64} className="text-accent animate-pulse-glow blur-sm" />
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
            {title}
          </h3>
          <p className="text-muted-foreground group-hover:text-accent transition-colors duration-300">
            {description}
          </p>
        </div>
      </div>
    </Card>
  );
});
