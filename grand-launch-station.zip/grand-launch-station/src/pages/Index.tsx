import { GameLauncher } from "@/components/GameLauncher";

const Index = () => {
  return <GameLauncher />;
};

export default Index;
